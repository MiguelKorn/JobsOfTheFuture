var btn = document.getElementById('nextScreen');

btn.addEventListener('click', nextScreen, false);

function nextScreen() {
    window.location = "pages/home.html";
}