var mv = QueryString.mv;
var optionOne = document.getElementById("optionOne");
var optionTwo = document.getElementById("optionTwo");

optionOne.href = "chooseJob.html?mv=" + mv + "&sc=0";
optionTwo.href = "chooseJob.html?mv=" + mv + "&sc=1";